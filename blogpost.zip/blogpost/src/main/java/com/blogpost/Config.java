package com.blogpost;

public class Config {
    public static String username = "modi";
    public static String password = "modi";   // include a new service class to encrypt the password. This is a bad practice.
    public static String style = "styles/style2.css"; //stylesheet for home pages
    public static String styleAdmin = "../styles/style1.css";  //stylesheet for admin pages
    public static String dbPass = "";
    public static String dbName = "root";
    public static int numRows = 10;   //number of articles to fetch in a single query.
    public static String footer = "Designed and Coded by <b>Navaneeth</b>&nbsp&nbsp<br>";
    public static String head = "<div style='text-align: center; font-size: 1.5em; color: #333;'><h1>MODI HARIVARDHAN</h1><br> Welcome to My Blog!</div>";
}
